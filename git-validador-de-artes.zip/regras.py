# regras.py (Versão com a lógica de busca restaurada)

from dataclasses import dataclass
from typing import Tuple, Optional, Dict, Any
import os

@dataclass
class RegraValidacao:
    largura: int
    altura: int
    formato_final: Tuple[str, ...]
    modo_cor: str
    orientacao: str
    resolucao_dpi: Optional[int] = None
    descricao: str = ""
    gabarito_img: str = ""

    def to_dict(self) -> dict:
        return self.__dict__

REGRAS_BASE: Dict[str, RegraValidacao] = {
    "divertix_home": RegraValidacao(largura=370, altura=550, formato_final=("JPEG", "PNG"), modo_cor="RGB", orientacao="vertical"),
    "divertix_atracao": RegraValidacao(largura=740, altura=380, formato_final=("JPEG", "JPG", "PNG"), modo_cor="RGB", orientacao="horizontal"),
    "divertix_carrossel_mobile": RegraValidacao(largura=375, altura=471, formato_final=("JPEG", "JPG", "PNG"), modo_cor="RGB", orientacao="vertical"),
    "divertix_carrossel_desktop": RegraValidacao(largura=1120, altura=400, formato_final=("JPEG", "JPG", "PNG"), modo_cor="RGB", orientacao="horizontal"),
    "site_teatro_home": RegraValidacao(largura=768, altura=1024, formato_final=("JPEG", "JPG", "PNG"), modo_cor="RGB", orientacao="vertical"),
}

TEATROS_CONFIG: Dict[str, Dict[str, Any]] = {
    "Teatro dos Grandes Atores": {
        "pasta": "grandes_atores",
        "regras": {
            # --- LÓGICA RESTAURADA AQUI ---
            # Garante que as regras para este teatro usem os nomes de arquivo corretos
            "divertix_home": {"descricao": "Divertix Home do Site – 370 x 550 px", "gabarito_img": "gabarito_divertix_home.png"},
            "divertix_atracao": {"descricao": "Divertix Tela da Atração – 740 x 380 px", "gabarito_img": "gabarito_divertix_tela_atracao.png"},
        }
    },
    "Teatro das Artes": {
        "pasta": "das_artes",
        "regras": {
            "divertix_home": {"descricao": "Divertix Home do Site – 370 x 550 px", "gabarito_img": "gabarito_divertix_home_370 x 550.png"},
            "divertix_atracao": {"descricao": "Divertix Tela da Atração – 740 x 380 px", "gabarito_img": "gabarito_divertix_tela_atracao 740 x 380.png"},
            "divertix_carrossel_mobile": {"descricao": "Divertix Carrossel Mobile – 375 x 471 px", "gabarito_img": "gabarito_divertix_carrossel_mobile 375 x 471.png"},
            "divertix_carrossel_desktop": {"descricao": "Divertix Carrossel Desktop – 1120 x 400 px", "gabarito_img": "gabarito_divertix_carrossel_desktop 1120 x 400.png"},
            "site_teatro_home": {"descricao": "Site do Teatro – 768 x 1024 px", "gabarito_img": "gabarito_site_home 768 X 1024.png"},
        }
    }
}

def carregar_regras(teatro: str) -> dict:
    teatro_config = TEATROS_CONFIG.get(teatro)
    if not teatro_config:
        return {}
    regras_finais = {}
    for regra_key, detalhes_especificos in teatro_config["regras"].items():
        regra_base = REGRAS_BASE.get(regra_key)
        if not regra_base:
            continue
        dados_regra = regra_base.to_dict()
        dados_regra.update(detalhes_especificos)
        caminho_gabarito = os.path.join(
            "assets", "teatros", teatro_config["pasta"], dados_regra["gabarito_img"]
        )
        dados_regra["gabarito_path"] = caminho_gabarito
        regras_finais[regra_key] = dados_regra
    return regras_finais